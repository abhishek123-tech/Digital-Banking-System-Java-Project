package backend.model;

import jakarta.persistence.*;

@Entity
@Table(name="accounts")
public class Account {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String accountNumber;

    private double balance;

    @OneToOne
    private User user;

    public Account(){}

    public Long getId(){ return id; }

    public String getAccountNumber(){ return accountNumber; }

    public void setAccountNumber(String accountNumber){
        this.accountNumber=accountNumber;
    }

    public double getBalance(){ return balance; }

    public void setBalance(double balance){
        this.balance=balance;
    }

    public User getUser(){ return user; }

    public void setUser(User user){
        this.user=user;
    }
}