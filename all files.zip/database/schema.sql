CREATE DATABASE banking_app;

USE banking_app;

CREATE TABLE users(
id INT PRIMARY KEY AUTO_INCREMENT,
name VARCHAR(100),
email VARCHAR(100),
password VARCHAR(100)
);

CREATE TABLE accounts(
id INT PRIMARY KEY AUTO_INCREMENT,
user_id INT,
balance DOUBLE
);

CREATE TABLE transactions(
id INT PRIMARY KEY AUTO_INCREMENT,
account_id INT,
type VARCHAR(50),
amount DOUBLE,
date TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);