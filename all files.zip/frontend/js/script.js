function register(){

const name=document.getElementById("name").value
const email=document.getElementById("email").value
const password=document.getElementById("password").value

fetch("http://localhost:8080/api/register",{
method:"POST",
headers:{
"Content-Type":"application/json"
},
body:JSON.stringify({name,email,password})
})
.then(res=>res.json())
.then(data=>{
alert("Registration Successful")
window.location="login.html"
})

}