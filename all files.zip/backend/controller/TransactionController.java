package backend.controller;

import backend.model.Transaction;
import backend.model.Account;
import backend.service.TransactionService;
import backend.service.AccountService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/transactions")
@CrossOrigin
public class TransactionController {

    @Autowired
    private TransactionService service;

    @Autowired
    private AccountService accountService;

    @GetMapping("/{number}")
    public List<Transaction> getTransactions(@PathVariable String number){

        Account acc=accountService.getAccount(number);

        return service.getTransactions(acc);
    }
}