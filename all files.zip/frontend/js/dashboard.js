function loadBalance(){

fetch("http://localhost:8080/api/account/balance")
.then(res=>res.json())
.then(data=>{
document.getElementById("balance").innerText=data.balance
})

}