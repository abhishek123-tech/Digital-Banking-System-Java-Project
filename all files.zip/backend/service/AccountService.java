package backend.service;

import backend.model.Account;
import backend.repository.AccountRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class AccountService {

    @Autowired
    private AccountRepository repo;

    public Account createAccount(Account acc){
        return repo.save(acc);
    }

    public Account getAccount(String number){
        return repo.findByAccountNumber(number);
    }

    public Account deposit(String number,double amount){

        Account acc=repo.findByAccountNumber(number);

        acc.setBalance(acc.getBalance()+amount);

        return repo.save(acc);
    }

    public Account withdraw(String number,double amount){

        Account acc=repo.findByAccountNumber(number);

        if(acc.getBalance()>=amount){

            acc.setBalance(acc.getBalance()-amount);
        }

        return repo.save(acc);
    }
}