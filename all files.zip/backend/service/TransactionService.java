package backend.service;

import backend.model.Transaction;
import backend.model.Account;
import backend.repository.TransactionRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class TransactionService {

    @Autowired
    private TransactionRepository repo;

    public Transaction saveTransaction(Account account,String type,double amount){

        Transaction t=new Transaction();

        t.setAccount(account);
        t.setType(type);
        t.setAmount(amount);
        t.setDate(LocalDateTime.now());

        return repo.save(t);
    }

    public List<Transaction> getTransactions(Account account){

        return repo.findByAccount(account);
    }
}