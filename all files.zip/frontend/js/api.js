const API_URL = "http://localhost:8080/api";

function registerUser(data){
return fetch(API_URL+"/register",{
method:"POST",
headers:{
"Content-Type":"application/json"
},
body:JSON.stringify(data)
})
}

function loginUser(data){
return fetch(API_URL+"/login",{
method:"POST",
headers:{
"Content-Type":"application/json"
},
body:JSON.stringify(data)
})
}