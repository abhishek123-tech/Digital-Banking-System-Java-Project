package backend.repository;

import backend.model.Transaction;
import backend.model.Account;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface TransactionRepository extends JpaRepository<Transaction,Long>{

    List<Transaction> findByAccount(Account account);
}