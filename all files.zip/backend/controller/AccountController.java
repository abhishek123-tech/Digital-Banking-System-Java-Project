package backend.controller;

import backend.model.Account;
import backend.service.AccountService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/account")
@CrossOrigin
public class AccountController {

    @Autowired
    private AccountService service;

    @PostMapping("/create")
    public Account create(@RequestBody Account acc){
        return service.createAccount(acc);
    }

    @GetMapping("/{number}")
    public Account get(@PathVariable String number){
        return service.getAccount(number);
    }

    @PostMapping("/deposit/{number}/{amount}")
    public Account deposit(@PathVariable String number,@PathVariable double amount){
        return service.deposit(number,amount);
    }

    @PostMapping("/withdraw/{number}/{amount}")
    public Account withdraw(@PathVariable String number,@PathVariable double amount){
        return service.withdraw(number,amount);
    }
}