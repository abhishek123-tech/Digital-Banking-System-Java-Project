package backend.repository;

import backend.model.Account;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AccountRepository extends JpaRepository<Account,Long>{

    Account findByAccountNumber(String accountNumber);
}